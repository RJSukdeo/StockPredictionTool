import guiUtil


def main():
    guiTools = guiUtil.IntroGUI()

if __name__ == '__main__':
    main()


